var CityName = "Clermont-Ferrand"; 
var LocationAbbreviation = "FR"; 
var Lang = "en"; // en, fr, nl, ru, cz, it, sp, de, zh, he, pl, pt
var UnitsType = true; // false for temperature in F and distance in mi else temperature in °C and distance in km
var Twentyfour = true;
var WeatherCacheTime = 20; // cache of the weather in minutes 
