var twentyfourhour = true;
var pad = true;

