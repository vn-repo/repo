var twentyfourhour = true;
var pad = false;
var iconSet = "Icon1"	     // Do not Modify.



