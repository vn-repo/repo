// touch(event) by am80ma (TeamIOS)
//  Modded by D-Shin (TeamIOS)
// don´t touch this header punk!!!

'use strict'
	var $$ = function(el){
	return document.getElementById(el);
}

var Xtouch = false;
function touch1() {
    
    if(Xtouch){
	Xtouch=false;
	$$("forecast").style.opacity = "1.0";
	$$("forecast").style.webkitTransform="scale(1.0,1.0)";
	$$("hourlyforecast").style.opacity = "0.0";
	$$("hourlyforecast").style.webkitTransform="scale(0.1,0.1)";	
	
    
	
	}else{
	Xtouch=true;
	$$("forecast").style.opacity = "0.0";
	$$("forecast").style.webkitTransform="scale(0.1,0.1)";	
	$$("hourlyforecast").style.opacity = "1.0";
	$$("hourlyforecast").style.webkitTransform="scale(1.0,1.0)";	
			
}}
