var PolygonNb = 5; // if WithMouvement is true, that will set this at 1 in code
var SizeOfPolygon = 100; // if WithMouvement is true
var Sides = 6;
var WithMouvement = false; // false = run with gravity else with mouvement with your phone
var FactorMouvementY = 5; //if WithMouvement is true
var FactorMouvementX = 5; //if WithMouvement is true
var FactorIniPositionX = 0.5; // if WithMouvement is true, x position will be at X * width
var FactorIniPositionY = 0.5; // if WithMouvement is true, y position will be at X * height
var TimeToDown = 4; // if WithMouvement is false, in sec
var TimeToUp = 2; // if WithMouvement is false, in sec
var FactorMinScale = 0.6; // if WithMouvement is false, max value 2
var FactorMaxScale = 0.9; // if WithMouvement is false, max value 2 
var BackgroundColor = "#000"; // rgb or # code or color's name
var BackgroundAlpha = 0.6; 
var PolygonAlpha = 1;