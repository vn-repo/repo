/* */ var savedElements = {"overlay":"","placedElements":{"boxOne":{"left":"249.5px","border-color":"#00000000","border-width":"0.7px","position":"absolute","border-radius":"30px","width":"60px","box-shadow":"black 0px 0px 30px","background":"linear-gradient(150deg,rgb(0,0,0) 100%)","height":"13px","background-color":"rgba(130, 130, 130, 0.38)","z-index":"1","border-style":"solid","top":10.5,"-webkit-transform":"rotate(0deg)"}},"iconName":"simply"}


