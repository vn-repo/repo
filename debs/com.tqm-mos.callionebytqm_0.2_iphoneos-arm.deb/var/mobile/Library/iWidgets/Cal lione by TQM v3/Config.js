var twentyfourh = true; // không thay đổi
var pad = true; // không thay đổi
var IconSet = "Icon2"; // không thay đổi
