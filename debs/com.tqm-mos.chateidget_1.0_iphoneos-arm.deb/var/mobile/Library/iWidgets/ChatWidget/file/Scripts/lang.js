

if (Lang == "ar") {
    var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    var shortdays = ["ألاحد", "ألاثنين", "ألثلاثاء", "ألاربعاء", "ألخميس", "ألجمعه", "ألسبت"];
    var oneletterdays = ["S","M","T","W","T.","F","S."];
    var months=["January","February","March","April","May","June","July","August","September","October","November","December"];
    var shortmonths = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "تشرين الثاني", "ديسمبر"];
    var hourtext = ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];

}


if (Lang == "en") {
    var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    var shortdays = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
    var oneletterdays = ["S","M","T","W","T.","F","S."];
    var shortmonths=["January","February","March","April","May","June","July","August","September","October","November","December"];
    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

}