var twentyfourhour = true; // TRẦN QUAMG MINH
var pad = true; // TRẦN QUAMG MINH
