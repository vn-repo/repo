function danhngon() {
    var quotes = new Array;

    quotes.push("<b>Nếu bạn sống lâu, bạn sẽ mắc phải những sai lầm. Nhưng nếu bạn học được từ những sai lầm đó, bạn sẽ trở nên tốt hơn. Dù bạn đối phó với nghịch cảnh theo cách nào, điều không quan trọng. Điều quan trọng là bạn không bao giờ, không bao giờ, không bao giờ từ bỏ.</b> <br><br>(Người Từng Trải)");

    quotes.push("<b>Hãy quay về hướng mặt trời, và bạn sẽ không thấy bóng tối.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Không quan trọng bạn đang đi đâu, có ánh sáng cuối con đường hay không và rất khó để đạt được điều gì đó, nhưng bạn có thể làm được và luôn nhìn về phía trước bạn sẽ tìm thấy mặt tích cực của vấn đề.</b> <br><br>(Ngạn ngữ phương Đông)");
	
    quotes.push("<b>Giá trị của mỗi người tuỳ thuộc vào lí tưởng của mình cao hay thấp.</b> <br><br>(P.Hymans)");

    quotes.push("<b>Những sự đam mê là những chuyến du lịch của trái tim.</b> <br><br>(Paul Morand)");

    quotes.push("<b>Học để trang hoàn đời sống và làm cho ta yêu đời hơn.</b> <br><br>(I.Viennot)");

    quotes.push("<b>Cố gắng mà viết ra những tư tưởng của mình là phương pháp hay nhất để suy tưởng.</b> <br><br>(Miguel De Unamuno)");

    quotes.push("<b>Thiếu phương pháp thì người tài cũng lỗi. Có phương pháp thì người thường cũng làm được chuyện phi thường.</b> <br><br>(Descartes)");

    quotes.push("<b>Sự hiểu biết của kẻ tầm thường thì rời rạc, không thống nhất. Sự hiểu biết của nhà khoa học thì đó chỉ là sự hiểu biết thống nhất phần nào thôi. Còn sự hiều biết của nhà triết học là sự hiểu biết đã hoàn toàn thống nhất.</b> <br><br>(H.Spencer)");

    quotes.push("<b>Hy vọng đánh thức sự can đảm trong khi thất vọng là điều tồi tệ cuối cùng.</b> <br><br>(V.Knebel)");

    quotes.push("<b>Con người sống không có tình thương cũng giống như vườn hoa không có ánh nắng mặt trời. Không có gì đẹp đẽ và hữu ích có thể nảy nở trong đó được.</b> <br><br>(Victor Hugo)");

    quotes.push("<b>Ta cố gắng làm việc tầm thường để trở nên phi thường.</b> <br><br>(Nữ tu sĩ Roselle)");

    quotes.push("<b>Con người bộc lộ đầy đủ nhất trong lúc làm việc chứ không phải trong những câu chuyện thông minh, những câu nói văn hoa, những lời hứa đẹp đẽ.</b> <br><br>(Ivanov)");

    quotes.push("<b>Không phải lập được những kỳ công cuộc đời mới tốt đẹp.</b> <br><br>(Henry Bordeux)");

    quotes.push("<b>Sự ganh ghét không biết ẩn thân. Nó tố cáo và kết án không cần bằng chứng, nó thổi phồng khuyết điểm.</b> <br><br>(Vauvenargues)");

    quotes.push("<b>Không nên coi thường những lỗi nhỏ. Một lỗi nhỏ bao giờ cũng khởi nguồn cho một lỗi lớn, những thói hư tật xấu đều là những đứa con của lỗi nhỏ sinh ra.</b> <br><br>(Xtan)");

    quotes.push("<b>Im lặng là hình thức khiêm tốn, hoặc hằn học nhất của sự phê phán.</b> <br><br>(Pierre Reverdy)");

    quotes.push("<b>Nếu người khác làm tổn thương anh, có thể anh sẽ quên đi sự thiệt hại đó, nhưng nếu anh làm tổn thương người khác thì điều đó thật khó quên.</b> <br><br>(Kahill Gibran)");

    quotes.push("<b>Nhìn thấy những cái đẹp khó hơn nhìn thấy những cái xấu.</b> <br><br>(Chateaubriand)");

    quotes.push("<b>Bất cứ sự hiểu biết gì cũng điều do quan sát và kinh nghiệm mà ra.</b> <br><br>(Saint Beuve)");

    quotes.push("<b>Điều gì không rõ ràng thì không nên thực nhận.</b> <br><br>(Descartes)");

    quotes.push("<b>Con người càng phát triển cao về trí tuệ và đạo đức, càng trở nên tự do hơn và cuộc sống càng thú vị hơn đối với họ.</b> <br><br>(A.Trekhop)");

    quotes.push("<b>Bắt đầu biết hối hận là bắt đầu một cuộc sống mới.</b> <br><br>(G.Eliot)");

    quotes.push("<b>Ai không kính trọng cuộc sống sẽ không xứng đáng với cuộc sống.</b> <br><br>(Leonard De Vinci)");

    quotes.push("<b>Thành công không phải là điều quan trọng. Quan trọng là sự nỗ lực.</b> <br><br>(Jouffroy)");

    quotes.push("<b>Ta không nên sợ kẻ thù công kích ta mà nên sợ người bạn nịnh ta.</b> <br><br>(Obregon)");

    quotes.push("<b>Càng hiểu biết nhiều, càng ít khi dám quả quyết.</b> <br><br>(Cách ngôn Italia)");

    quotes.push("<b>Không có quyển sách nào hay đối với người dốt. Không có tác phẩm nào dở đối với người khôn.</b> <br><br>(Diderot)");

    quotes.push("<b>Cách giữ lời tốt nhất là không nên hứa ra.</b> <br><br>(Napoleon)");

    quotes.push("<b>Suy nghĩ thực tế, cảm nhận những điều đẹp đẽ, mong muốn cái tốt lành, đó chính là mục đích của cuộc sống hướng thiện.</b> <br><br>(Plato)");

    quotes.push("<b>Đời là cuộc đấu tranh liên tục, nó luôn được cải biên với nhưng khó khăn mới. Và chúng ta sẽ chiến thắng nhưng bao giờ cũng phải trả giá.</b> <br><br>(Mirko Gomex)");

    quotes.push("<b>Nếu bạn muốn đi qua cuộc đời không phiền toái thì chẳng nên bỏ đá vào túi mà đeo.</b> <br><br>(V.Shemtchisnikov).");

    quotes.push("<b>Thiên đường ở chính trong ta. Địa ngục cũng do lòng ta mà có.</b> <br><br>(Chúa Jésus)");

    quotes.push("<b>Cuộc sống của chúng ta là cố gắng và lao động. Sự nghỉ ngơi hoàn toàn chỉ chờ chúng ta ở trong những nấm mồ.</b> <br><br>(Dex to ep xki)");

    quotes.push("<b>Hãy can đảm mà sống bởi vì ai cũng phải chết một lần.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Đừng đi qua thời gian mà không để lại dấu vết.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Nhiều người đã khóc khi chào đời, phàn nàn khi đang sống và chán chường khi tắt thở.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Bốn mươi là tuổi già của lớp trẻ, năm mươi là tuổi trẻ của lớp già.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Bao giờ ta cũng phải luôn luôn có một nơi nào để đến.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Những người vui hưởng cuộc sống thì không  bao giờ là kẻ thất bại.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Chúng ta hãy cố gắng để chỉ chết một lần thôi.</b> <br><br>(Cantauzene)");

    quotes.push("<b>Bạn có yêu đời không? Vậy đừng phung phí thời gian vì chất liệu của cuộc sống được làm bằng thời gian.</b> <br><br>(Franklin)");

    quotes.push("<b>Đời người được đo bằng tư tưởng và hành động chứ không phải bằng thời gian.</b> <br><br>(Emerson)");

    quotes.push("<b>Cuộc đời ngắn ngủi không cho phép ta hy vọng quá xa.</b> <br><br>(Ngạn ngữ Latin)");

    quotes.push("<b>Đừng sống theo điều ta mong muốn. Hãy sống theo điều ta có thể.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Người muốn đi thì số phận dẫn đi. Người không muốn đi thì số phận kéo lê.</b> <br><br>(Ngạn ngữ Latin)");

    quotes.push("<b>Đời là một hài kịch đối với những người hay suy nghĩ, và là một bi kịch đối với những người đa cảm.</b> <br><br>(G.Suip)");

    quotes.push("<b>Mục đích tối trọng của đời người không phải là sự hiểu biết, mà là hành động.</b> <br><br>(A.Haoxlay)");

    quotes.push("<b>Cuộc sống như một cuốn sách. Kẻ điên rồ giở qua nhanh chóng. Người khôn ngoan vừa đọc vừa suy nghĩ, vì biết rằng mình chỉ được đọc có một lần.</b> <br><br>(Giăng Pôn)");

    quotes.push("<b>Một người nào đó đã chết, điều đó chưa chắc chắn đã phải người ấy đã từng sống.</b> <br><br>(X.Letx)");

    quotes.push("<b>Khi con người ta sống chỉ vì mình thì trở thành thừa đối với những người còn lại.</b> <br><br>(I.Rađep)");

    quotes.push("<b>Con người có thể chết được là để anh ta biết quý thời gian.</b> <br><br>(I.Rađep)");

    quotes.push("<b>Thảm họa của tuổi già không phải là ở chỗ người ta đã già, mà là ở chỗ người ta không còn cảm thấy trẻ trung nữa.</b> <br><br>(O.Uaind)");

    quotes.push("<b>Thời gian không đo lường bằng năm tháng, mà bằng những gì chúng ta làm được.</b> <br><br>(H.Cason)");

    quotes.push("<b>Cuộc sống là nghĩa vụ ngay cả trong trường hợp nó chỉ diễn ra trong khoảnh khắc.</b> <br><br>(W.Gớt)");

    quotes.push("<b>Người ta còn sống mà làm gì, khi mà sau gót giày, gió quét sạch ngay dấu tích cuối cùng của ta.</b> <br><br>(S.Xvâygơ)");

    quotes.push("<b>Khi không còn ai ghen tị với bạn, thì hãy xem lại liệu mình đã sống đúng chưa.</b> <br><br>(M.Ghenin)");

    quotes.push("<b>Người nào có thể làm mỗi giây phút đều tràn ngập một nội dung sâu sắc, thì người đó sẽ kéo dài vô tận cuộc đời mình.</b> <br><br>(I.Cuôcxơ)");

    quotes.push("<b>Chỉ có cuộc sống vì người khác mới là cuộc sống đáng quý.</b> <br><br>(A.Einstein)");

    quotes.push("<b>Điều quan trọng không phải chúng ta sống được bao lâu, mà chúng ta phải sống như thế nào.</b> <br><br>(Bailey)");

    quotes.push("<b>Khi bạn sinh ra đời, bạn khóc, còn mọi người xung quanh cười. Hãy sống sao cho khi bạn qua đời, mọi người khóc còn bạn, bạn cười.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Dũng cảm, đó là trách nhiệm được ý thức đến cùng.</b> <br><br>(Paplenko)");

    quotes.push("<b>Dễ dãi là phương châm của thể xác và là vai trò chính của tâm hồn.</b> <br><br>(Ngạn ngữ Đức)");

    quotes.push("<b>Nếu sự khiêm nhường của bạn khiến mọi người để ý, thì hẳn có chút gì đó chẳng bình thường.</b> <br><br>(M.Ghenin)");

    quotes.push("<b>Can đảm gia tăng khi người ta dám liều và nỗi sợ sệt cũng gia tăng khi người ta do dự. Trong tình thế nguy cấp, sự liều lĩnh thay thế cho sự khôn ngoan.</b> <br><br>(P.Syrus)");

    quotes.push("<b>Mỗi người đều có 3 tính cách. Tính cách phô ra, tính cách họ có và tính cách họ nghĩ rằng họ có.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Người có một tinh thần sâu sắc, cần phải tự đào tạo một cái học để khám phá những tế nhị của lòng người.</b> <br><br(Vauvenargues)");

    quotes.push("<b>Đức trong sạch là sự huy hoàng của con người nội tâm. Nó là sức mạnh tột đỉnh khóa chặt tâm hồn trước những điều thấp hèn, và mở rộng tâm hồn trước những điều cao quý.</b> <br><br>(Jean De Rusbrock)");

    quotes.push("<b>Khiêm tốn thật sự không có nghĩa là không biết đến những giá trị của mình, mà chính là biết nhận những giá trị ấy.</b> <br><br>(J.C.Hare)");

    quotes.push("<b>Khiêm tốn bao nhiêu cũng chưa đủ, tự kiêu một chút cũng là nhiều</b> <br><br>(Karl Marx)");

    quotes.push("<b>Sự yêu chuộng cái đẹp là phần cốt yếu của một nhân tính lành mạnh.</b> <br><br>(J.Ruskin)");

    quotes.push("<b>Cái gì hấp dẫn và đẹp đẽ chẳng phải luôn luôn là tốt, nhưng cái gì tốt thì luôn luôn đẹp.</b> <br><br>(Ninonde Lenenles)");

    quotes.push("<b>Tôi biết có một điều tốt đẹp hơn cả sự ngay thẳng, ấy là sự khoan dung.</b> <br><br>(V.Hugo)");

    quotes.push("<b>Thói quen là một bản tính thứ hai.</b> <br><br>(Cicero)");

    quotes.push("<b>Danh dự như que diêm, cháy một lần là hết.</b> <br><br>(M.Pagnol)");

    quotes.push("<b>Sắc đẹp là hoa, còn đạo đức là quả của cuộc đời.</b> <br><br>(Ngạn ngữ Mỹ)");

    quotes.push("<b>Bản chất giản dị là kết quả tự nhiên của tư tưởng sâu sắc.</b> <br><br>(Hazlitt)");

    quotes.push("<b>Hãy dạy đạo đức cho con cái bạn, chỉ có đạo đức chứ không phải vàng bạc mớ làm chúng sung sướng.</b> <br><br>(Beethoven)");

    quotes.push("<b>Sự cao cả của con người nằm trong sức mạnh tư tưởng.</b> <br><br>(Tục ngữ Anh)");

    quotes.push("<b>Đừng cố gò gẫm để hình thành nhân cách, điều đó cũng giống như cố bắt nụ hồng xanh nở hoa vậy. Bạn hãy sống sao cho tốt nhất, và nhân cách của bạn tự nó sẽ hình thành.</b> <br><br>(Henry James)");

    quotes.push("<b>Những tâm hồn thanh nhã không bao giờ sống chung được với những kẻ thô tục tầm thường.</b> <br><br>(An Bel Bonnard)");

    quotes.push("<b>Nếu muốn, bạn có thể tin rằng núi cao có thể chuyển được, nhưng đừng bao giờ tin rằng con người có thể thay đổi được cá tính.</b> <br><br>(Ngạn ngữ I Ran)");

    quotes.push("<b>Tri thức làm người ta khiêm tốn, ngu si làm người ta kiêu ngạo.</b> <br><br>(Ngạn ngữ Anh)");

    quotes.push("<b>Danh dự giống như viên đá quý, chỉ một vết nhỏ cũng làm mờ ánh lấp lánh của nó và làm mất toàn bộ giá trị của nó.</b> <br><br>(A.Bôsan)");

    quotes.push("<b>Khoảng cách giữa đạo đức và thói xấu hẹp đến nỗi chỉ vừa đủ cho hoàn cảnh chêm vào.</b> <br><br>(J.M.Braodo)");

    quotes.push("<b>Can đảm là đức hạnh số một của con người, vì nó đảm bảo cho tất cả những hạnh phúc khác.</b> <br><br>(Churchill)");

    quotes.push("<b>Mình thế nào mà không dám tỏ ra như thế là mình khinh mình.</b> <br><br>(Mat Xi Lông)");

    quotes.push("<b>Kiêu hãnh đốt nóng lòng can đảm, kích thích tài năng, phát triển tư chất tự nhiên cho tâm hồn, biết oán ghét cái hèn hạ ti tiện, và không xứng đáng với thiện cảm mà tự nơi chúng ta có.</b> <br><br>(Gômông)");

    quotes.push("<b>Giản dị là điều khó nhất trên đời, đó là sự giới hạn tột cùng của sự từng trải và là nỗ lực cuối cùng của thiên tài.</b> <br><br>(G.Xăng)");

    quotes.push("<b>Nếu trái tim bạn là một đóa hồng, miệng bạn sẽ thốt ra những lời ngát hương.</b> <br><br>(Ngạn ngữ Nga)");

    quotes.push("<b>Thiên tài và đức hạnh giống như viên kim cương, đẹp nhất là lồng trong chiếc khung giản dị.</b> <br><br>(X.Batle)");

    quotes.push("<b>Sức mạnh lớn nhất thường chỉ đơn giản là sự kiên nhẫn.</b> <br><br>(Giôxep Côtman)");

    quotes.push("<b>Tiêu chuẩn đánh giá con người là khát vọng vươn tới sự hoàn chỉnh.</b> <br><br>(W.Gớt)");

    quotes.push("<b>Khi mọi sự vô phương cứu chữa, thì chính là lúc lòng kiên nhẫn cần được dùng đến.</b> <br><br>(G.Huttơn)");

    quotes.push("<b>Tính cách của con người được bộc lộ trung thực nhất qua những sự đối xử tình cờ nhất.</b> <br><br>(I.Rađep)");

    quotes.push("<b>Những phẩm chất tâm hồn không thể bị tổn hại vì vẻ ngoài xấu xí, trong khi vẻ đẹp tâm hồn cũng ánh cả ra bên ngoài làm vẻ đẹp bên ngoài cũng trở nên đẹp.</b> <br><br>(Seneca)");

    quotes.push("<b>Những người vĩ đại thật sự bao giờ cũng giản dị, cách cư xử của họ tự nhiên và thoải mái.</b> <br><br>(F.Clinghe)");

    quotes.push("<b>Giản dị chẳng những là điều tốt đẹp nhất, mà còn là điều cao thượng nhất.</b> <br><br>(T.Phôntakê)");

    quotes.push("<b>Chân thành là nguồn sinh ra mọi thiên tài.</b> <br><br>(C.Becnê)");

    quotes.push("<b>Phần thưởng đáng giá nhất là phần thưởng do danh dự đem lại, không có gì hơn.</b> <br><br>(A.France)");

    quotes.push("<b>Rất ít người, và hơn nữa chỉ những người tuyệt vời nhất mới có thể nói một cách giản dị và chân thành. Tôi không biết.</b> <br><br>(D.Pi Xa Rep)");

    quotes.push("<b>Đức hạnh lớn nhất mà bên cạnh đó mọi đức hạnh khác đều mờ nhạt đi, đấy là không làm hại ai và tùy sức mà giúp đỡ mọi người.</b> <br><br>(Gơ Ut Sac Di Ni)");

    quotes.push("<b>Người nào tô điểm thêm vẻ quan trọng cho công việc tầm thường, người đó sẽ là kẻ tầm thường trong những việc quan trọng.</b> <br><br>(M.Catông)");

    quotes.push("<b>Trí tuệ của con người trưởng thành trong tĩnh lặng, còn tính cách trưởng thành trong bão táp.</b> <br><br>(W.Gớt)");

    quotes.push("<b>Người cao thượng là người không bao giờ làm một điều gì để hạ thấp người khác.</b> <br><br>(A.Ca Sơn)");

    quotes.push("<b>Nếu như có một cái gì đó mạnh hơn số phận thì đó là lòng dũng cảm, không gì lay chuyển nổi để chịu đựng nó.</b> <br><br>(W.Gớt)");

    quotes.push("<b>Chỉ có ý thức độc lập và lòng tự trọng mới nâng chúng ta lên trên những nhỏ nhen của cuộc sống và những bão táp của số phận.</b> <br><br>(A.Puxkin)");

    quotes.push("<b>Trên đường đời, hành lí của con người cần mang theo là lòng kiên nhẫn và tính chịu đựng.</b> <br><br>(Maiacopxki)");

    quotes.push("<b>Chỉ có những khát vọng và những khát vọng lớn lao mới có thể nâng tâm hồn lên tầm vĩ đại.</b> <br><br>(Điđơrô)");

    quotes.push("<b>Một cách chắc chắn nhất để nâng cao phẩm cách con người là đặt nó ra khỏi sự nhu cầu.</b> <br><br>(A.Blanki)");

    quotes.push("<b>Trên đời này, không có cái thái quá nào đẹp hơn cái thái quá về sự tri ân.</b> <br><br>(La Bruyere)");

    quotes.push("<b>Nếu danh dự bắt buộc phải lên tiếng mà lại im lặng thì là một sự hèn nhát.</b> <br><br>(La Coocđơ)");

    quotes.push("<b>Căn bệnh nặng nhất của tâm hồn là sự lãnh đạm.</b> <br><br>(D.Tôkenvin)");

    quotes.push("<b>Nhân từ ngọt ngào là dấu hiệu của tính cao thượng.</b> <br><br>(Tago)");

    quotes.push("<b>Sự bình dị là sự nối giữa nhân ái và sắc đẹp.</b> <br><br>(Ngạn ngữ Hy Lạp)");

    quotes.push("<b>Không có sự vĩ đại nào lại không có sự giản dị, lòng tốt và sự thật.</b> <br><br>(L.N.Tonxtôi)");

    quotes.push("<b>Sự chân thành là điều tốt đẹp nhất bạn có thể đem trao tặng một người. Sự thật, lòng tin cậy, tình bạn và tình yêu đều tùy thuộc vào điều đó cả.</b> <br><br>(Elvis Presle)");

    quotes.push("<b>Mỗi người bạn làm nên một thế giới trong ta, một thế giới chỉ hình thành khi ta gặp họ.</b> <br><br>(Anais Nin)");

    quotes.push("<b>Kẻ nào không biết lặng thinh, hiếm khi biết lên tiếng đúng lúc.</b> <br><br>(Gibran)");

    quotes.push("<b>Không có gì làm con người ta nghi ngờ bằng ít kiến thức.</b> <br><br>(Bacon)");

    quotes.push("<b>Người ta không mắc sai lầm vì dốt nát mà vì tưởng mình là giỏi.</b> <br><br>(D.Granin)");

    quotes.push("<b>Thường thường sự thử thách lòng can đảm không phải dám chết mà là dám sống.</b> <br><br>(Alifieri Osaester)");

    quotes.push("<b>Có những cánh cửa của con tim mà trí thông minh không mở được.</b> <br><br>(M.Jouhandeau)");

    quotes.push("<b>Kiêu ngạo là sự bắt đầu của tất cả những lỗi lầm.</b> <br><br>(J.Đe Maistre)");

    quotes.push("<b>Con đường duy nhất để thoát khỏi gian khổ là đi xuyên qua nó.</b> <br><br>(Amony Mour)");

    quotes.push("<b>Hãy yêu sự thật nhưng cũng phải tha thứ lỗi lầm.</b> <br><br>(Voltaire)");

    quotes.push("<b>Không phải luôn nói ra điều ta nghĩ mà phải luôn nghĩ về điều ta nói.</b> <br><br>(Lambert)");

    quotes.push("<b>Những đam mê mãnh liệt đôi khi còn để ta nghỉ ngơi, nhưng sự hiếu thắng thì không bao giờ.</b> <br><br>(La Rochefoucault)");

    quotes.push("<b>Hạnh phúc giống như thủy tinh, càng rực rỡ bao nhiêu càng mong manh bấy nhiêu.</b> <br><br>(P.Syrus)");

    quotes.push("<b>Trong đời có một điều tệ hại hơn thất bại đó là không dám thực hiện.</b> <br><br>(Frankin Roosevelt)");

    quotes.push("<b>Ba thứ không bao giờ trở lại là: Tên đã bay, lời đã nói, ngày đã qua.</b> <br><br>(Thomas Carlude)");

    quotes.push("<b>Ghen ghét thường gây tai họa cho bản thân mình hơn là là cho người bị ghen ghét.</b> <br><br>(A.Duyma)");

    quotes.push("<b>Trong giao thiệp đừng đổi bạn thành thù, mà hãy đổi thù thành bạn.</b> <br><br>(Pitago)");

    quotes.push("<b>Đến ăn uống nhà bạn thì nên chậm, Khi bạn bè gặp nạn thì đến thật nhanh.</b> <br><br>(Xi Long)");

    quotes.push("<b>Điều khôn ngoan nhất là phải luôn ghi nhớ rằng, không có thành công hay thất bại nào là cuối cùng.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Đường tuy ngắn, không đi không đến. Việc tuy nhỏ, không làm không nên.</b> <br><br>(Tuân Tử)");

    quotes.push("<b>Khi sống sung túc, phẩm hạnh lớn nhất là sự điều độ. Khi gặp tai họa phẩm hạnh lớn nhất là kiên cường.</b> <br><br>(Bacon)");

    quotes.push("<b>Người đàn ông nào cũng muốn người đàn bà yêu quý của cuộc đời mình là người trí thức, khiêm nhường trong phòng khách, một người duyên dáng nơi công cộng và là người nhà kinh tế trong nội trợ.</b> <br><br>(R.Gamratop)");

    quotes.push("<b>Anh hãy tự giúp anh trước. Trời sẽ giúp anh sau.</b> <br><br>(La Fontaine)");

    quotes.push("<b>Đời là một hài kịch, đối với những người hay suy nghĩ, và là một bi kịch đối với những người hay đa cảm.</b> <br><br>(G.Suip)");

    quotes.push("<b>Ai yêu mãnh liệt, kẻ đó ít lời.</b> <br><br>(Catxitilone)");

    quotes.push("<b>Yêu đương không có đạo đức, chỉ là sự nhu nhược và hỗn loạn.</b> <br><br>(La Cordaire)");

    quotes.push("<b>Những điều chúng ta biết chỉ là giọt nước. Những điều chúng ta không biết là cả một đại dương.</b> <br><br>(Newton)");

    quotes.push("<b>Những bác sĩ mát tay nhất thế giới là điều độ, bình tĩnh và vui vẻ.</b> <br><br>(G.Suip)");

    quotes.push("<b>Lúc giận bạn đừng làm gì hết. Có khi nào bạn giăng buồm giữa lúc bão tố không?</b> <br><br>(Pot De Luz)");

    quotes.push("<b>Người con gái thích được khen dù xấu. Vì thế cho nên người đàn bà nào cũng thường hay chết vì người đàn ông am hiểu điều đó.</b> <br><br>(Pascal)");

    quotes.push("<b>Lòng tự ái làm nên tai họa cho phần đông đàn bà hơn là tình yêu.</b> <br><br>(La Rochefoucauld)");

    quotes.push("<b>Mỗi người đàn bà đều có một nét quyến rũ kỳ bí, nếu họ không kiêu hãnh và bướng bỉnh.</b> <br><br>(Joanna Baillie)");

    quotes.push("<b>Người đàn bà không bao giờ thấy điều gì mình làm cho họ, họ chỉ thấy điều mà mình không làm.</b> <br><br>(G.Courteline)");

    quotes.push("<b>Phần đông những người đàn bà đoan chính là những kho tàng bí mật, chỉ được gìn giữ chắc chắn khi không có ai biết tìm đến.</b> <br><br>(La Rochefoucauld)");

    quotes.push("<b>Người đàn bà tha thứ được những sự thiệt hại cho họ, nhưng không bao giờ quên được những sự khinh miệt.</b> <br><br>(Haliburton)");

    quotes.push("<b>Ánh mắt của phụ nữ nói lên với nhiều duyên dáng, một cách rất ân cần cái điều mà miệng họ không dám thốt ra.</b> <br><br>(Maurivaux)");

    quotes.push("<b>Yêu tất cả mọi đàn bà dễ hơn là yêu một người độc nhất.</b> <br><br>(Etienne Ray)");

    quotes.push("<b>Tình yêu thành thật làm cho người đàn bà trở nên kín đáo và ít bộc lộ.</b> <br><br>(Barthe)");

    quotes.push("<b>Tham vọng của người đàn bà là chiếm được lòng yêu của người những kẻ chung quanh và kế cận bên mình, chứ không cần lòng kính cẩn tôn sùng của những người xa lạ.</b> <br><br>(Gina Lombroso)");

    quotes.push("<b>Ðàn bà luôn luôn sẵn lòng hy sinh nếu bạn cho họ có cơ hội. Sở trường của họ chính là nhường nhịn.</b> <br><br>(Somerset Maugham)");

    quotes.push("<b>Đau khổ là khuân đúc tâm hồn người đàn bà để trở thành cao cả.</b> <br><br>(Gina Lombroso)");

    quotes.push("<b>Người đàn bà không sợ chết, không sợ đau khổ, nhưng chỉ lo sợ khi mình chết mà chưa được người mình thương yêu biết đến tình yêu của mình.</b> <br><br>(Gina Lombroso)");

    quotes.push("<b>Quả tim của người đàn bà không bao giờ già cỗi, và một khi nó không yêu nữa thì đó là vì nó đã ngừng đập.</b> <br><br>(P.Rochepedre)");

    quotes.push("<b>Cảm rồi yêu, đau khổ rồi lại hy sinh. Đó là những đề tài chính trong cuộc đời của người đàn bà.</b> <br><br>(Goethe)");

    quotes.push("<b>Rung động, yêu thương, đau khổ, hy sinh, tất cả sẽ mãi mãi là những trang tình sử của người đàn bà.</b> <br><br>(Honore De Balzac)");

    quotes.push("<b>Một người đàn bà hoặc yêu hay ghét, họ không lưng chừng.</b> <br><br>(Publilius Syrus)");

    quotes.push("<b>Nhà không có đàn bà như thân xác mà thiếu linh hồn.</b> <br><br>(Danh ngôn Pháp)");

    quotes.push("<b>Người đàn bà như bông hoa, chỉ nhả mùi thơm trong bóng tối.</b> <br><br>(Lamenais)");

    quotes.push("<b>Có ba thứ làm cho con tim ta mát rượi và quên hết mọi nỗi buồn. Đó là nước, hoa và sắc đẹp của đàn bà.</b> <br><br>(Phạn)");

    quotes.push("<b>Kẻ nói tốt cho phụ nữ là kẻ chưa biết rõ phụ nữ, còn kẻ nói xấu phụ nữ là kẻ không biết gì cả về phụ nữ.</b> <br><br>(Pigault Lebrun)");

    quotes.push("<b>Cái khó khăn chính đối với người đàn bà đức hạnh không phải là chinh phục họ, mà là đưa họ vào một nơi khép kín. Cái đức hạnh của họ làm bằng những cánh cửa nửa mở, nửa đóng.</b> <br><br>(Jean Giradoux)");

    quotes.push("<b>Một người con gái chỉ có thể giữ được tình yêu, không phải tình yêu mà nàng cảm hứng, nhưng là tình yêu mà nàng hoài bão, chỉ có kim cương mới rạch được kim cương, chỉ có tình yêu mới đủ mạnh để chống lại tình yêu.</b> <br><br>(G.Ạ Caillavet & R.De Flers)");

    quotes.push("<b>Đàn bà chỉ trao cho tình bạn cái gì mà họ mượn được ở tình yêu.</b> <br><br>(Chamfort)");

    quotes.push("<b>Cái lỗi lầm lớn của người đàn bà là luôn luôn tìm cách kết bạn với người đàn ông họ yêu, thay vì kiếm một người đàn ông yêu họ.</b> <br><br>(La Bruyere)");

    quotes.push("<b>Phụ nữ rất thích tiết kiệm trong sự hoang phí của họ.</b> <br><br>(Friedrich Hebbel)");

    quotes.push("<b>Tình cảm của người đàn bà là một thứ tình khó hiểu. Khi ra đường mà có người khen đẹp thì tự cao, khi không có người hỏi đến thì tự cho là mình bạc số.</b> <br><br>(Clémenceau)");

    quotes.push("<b>Người đàn bà luôn luôn được coi như ngang hàng với vua chúa. Người đời nịnh bợ họ vì lợi chứ không phải vì yêu.</b> <br><br>(Rochebrune)");

    quotes.push("<b>Nếu trừng trị người đàn bà thì người đời cho là vũ phu. Còn không trừng trị người đàn bà thì bị người đời cho là sợ vợ.</b> <br><br>(Scott Fitgérald)");

    quotes.push("<b>Người ta sẵn sàng tha thứ tất cả đối với người đàn bà mình thật lòng yêu mến. Và chính vì thế mà tình yêu trở nên khó thở.</b> <br><br>(J.Chardonnea)");

    quotes.push("<b>Lòng người đàn bà là một biển thẳm, mà đáy biển còn có thể dò được, nhưng lòng dạ đàn bà thì không.</b> <br><br>(Riccoboni)");

    quotes.push("<b>Đàn bà cũng như cái chăn bông về mùa hạ, đắp vào thì quá nóng nhưng bỏ ra thì lạnh.</b> <br><br>(Danh ngôn Nigri)");

    quotes.push("<b>Hai người đàn bà họp lại thành một cái chăn bông đẹp, ba người thành một cái gì khá ồn rồi, nhưng bốn người thì thành một cái chợ.</b> <br><br>(Gabriel Merurier)");

    quotes.push("<b>Sức mạnh của đàn bà là ở chỗ nói nhiều.</b> <br><br>(Danh ngôn Nigri)");

    quotes.push("<b>Người đàn bà khôn ngoan là người có nhiều điều muốn nói nhưng không nói ra.</b> <br><br>(Danh ngôn Ba Tư)");

    quotes.push("<b>Chim họa mi có thể quên hót, chứ đàn bà không thể quên nói.</b> <br><br>(Danh ngôn Tây Ban Nha)");

    quotes.push("<b>Muốn cho người đàn bà nói, có hàng ngàn cách khác nhau, nhưng không có cách nào làm họ câm miệng hết.</b> <br><br>(Guillaume Bouchet)");

    quotes.push("<b>Khen đàn bà thì cứ tha hồ nói dối, họ sẽ tin hết mình.</b> <br><br>(Danh ngôn Pháp)");

    quotes.push("<b>Không có lời nói dối kỳ quái nào mà người đàn bà chẳng tin, nếu đó cũng là lời khen nàng.</b> <br><br>(Khuyết danh)");

    quotes.push("<b>Chưa có người đàn bà nào soi gương mà thấy mình xấu cả.</b> <br><br>(Cesar Oudin)");

    quotes.push("<b>Người đàn bà đẹp, ba phần là do cái đẹp trời cho, còn bảy phần là nhờ đồ trang sức, và phẫu thuật thẩm mỹ.</b> <br><br>(Danh ngôn Trung Hoa)");

    var text = (quotes[(Math.floor(Math.random() * quotes.length))]);
    
    return text;
}