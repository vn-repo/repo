/* */ var savedElements = {"overlay":"","placedElements":{"boxOne":{"left":"38.6px","border-color":"rgba(32,220,220,0.80)","border-width":"2px","position":"absolute","border-radius":"30px","width":"40px","box-shadow":"rgba(32,220,220,0.80) 0px 0px 12px","background":"linear-gradient(150deg,rgba(32,178,170,0.50),rgba(255,255,255,0) 50%,rgba(255,50,200, 0.50) 90%)","height":"40px","background-color":"rgba(130, 130, 130, 0.38)","z-index":"1","border-style":"solid","top":480.2,"-webkit-transform":"rotate(0deg)"}},"iconName":"simply"}


