#import <UIKit/UIKit.h>

@interface MSHJelloLayer : CAShapeLayer

@property BOOL shouldAnimate;

@end