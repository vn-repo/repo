if (Lang == "vn") {
    var days = ["Chủ nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy"];
    var months=["01","02","03","04","05","06","07","08","09","10","11","12"];
    var weatherdesc = ["Có lốc tố", "Bão nhiệt đới", "Trời có bão", "Có giông", "Có giông", "Có tuyết rơi", "Có mưa đá", "Có mưa đá", "Mưa phùn lạnh giá", "Trời mưa phùn", "Trời lạnh giá", "Trời có mưa", "Trời có mưa", "Trời đang mưa", "Có bão", "Có tuyết rơi", "Có tuyết rơi", "Có tuyết rơi", "Có mưa đá", "Có mưa đá", "Có mưa bụi", "Nhiều sương mù", "Sương mù nhẹ", "Có sương mù", "Có gió mạnh", "Có gió", "Trời lạnh", "Trời nhiều mây", "Trời nhiều mây", "Trời nhiều mây", "Trời nhiều mây", "Trời nhiều mây", "Trời quang", "Trời nắng", "Trời trong", "Trời trong", "Có mưa đá", "Trời nóng", "Có sấm sét", "Có sấm sét", "Có sấm sét", "Có mưa", "Tuyết rơi nhiều", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Trời ít mây", "Có giông", "Có giông", "Có giông", "blank"]
}

if (Lang == "en") {
    var days = ["Chủ nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy"];
    var months=["01","02","03","04","05","06","07","08","09","10","11","12","ngày 10 tháng","ngày 11 tháng","ngày 12 tháng"];
    var weatherdesc = ["Có lốc tố", "Bão nhiệt đới", "Trời có bão", "Có giông", "Có giông", "Có tuyết rơi", "Có mưa đá", "Có mưa đá", "Mưa phùn lạnh giá", "Trời mưa phùn", "Trời lạnh giá", "Trời có mưa", "Trời có mưa", "Trời đang mưa", "Có bão", "Có tuyết rơi", "Có tuyết rơi", "Có tuyết rơi", "Có mưa đá", "Có mưa đá", "Có mưa bụi", "Nhiều sương mù", "Sương mù nhẹ", "Có sương mù", "Có gió mạnh", "Có gió", "Trời lạnh", "Trời nhiều mây", "Trời nhiều mây", "Trời nhiều mây", "Trời nhiều mây", "Trời nhiều mây", "Trời quang", "Trời nắng", "Trời trong", "Trời trong", "Có mưa đá", "Trời nóng", "Có sấm sét", "Có sấm sét", "Có sấm sét", "Có mưa", "Tuyết rơi nhiều", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Trời ít mây", "Có giông", "Có giông", "Có giông", "blank"]
}