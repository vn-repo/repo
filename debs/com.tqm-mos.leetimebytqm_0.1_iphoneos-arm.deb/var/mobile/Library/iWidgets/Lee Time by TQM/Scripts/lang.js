var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'en',
    $$ = function (el) {
        return document.getElementById(el);
    },
    translate = {
        en: {
            weekday: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
            sday: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
            month: ["January","February","March","April","May","June","July","August","September","October","November","December"],
            smonth: ["January","February","March","April","May","June","July","August","September","October","November","December"]
        }
    };
if (!translate[current]) {
    current = 'en';
}
