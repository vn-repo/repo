
var calljax = function (url) {
var xmlhttp,
        url = 'file:///var/mobile/Documents/widgetweather.xml', //url
    xmlhttp = new XMLHttpRequest(); // create a new http request           
    xmlhttp.open("GET", url, false); //open url with our url
    xmlhttp.send(); //start it
               var shit = {},
                    wwxml = xmlhttp.responseXML.documentElement,
                            cc = wwxml.getElementsByTagName('currentcondition')[0],
                            d = wwxml.getElementsByTagName('day')[0],
                            df = wwxml.getElementsByTagName('dayforcast')[0],
                            day = df.getElementsByTagName('day'),
                            date = new Date();
                        weather.city = cc.getElementsByTagName('city')[0].textContent;
                        weather.country = cc.getElementsByTagName('extraLocCountry')[0].textContent;        
                            update = cc.getElementsByTagName('updatetimestring')[0].textContent;
                           
                        fio = cc.getElementsByTagName('fioMinuteSummary')[0].textContent;
                        address = cc.getElementsByTagName('extraLocLine1')[0].textContent;

storm = cc.getElementsByTagName('fioStormDistance')[0].textContent;

direction = cc.getElementsByTagName('fioStormBearing')[0].textContent;
             
                        statelong = cc.getElementsByTagName('extraLocState')[0].textContent;

                        stateshort = cc.getElementsByTagName('extraLocStateCode')[0].textContent;
                       
                    };
setTimeout(function () {
                calljax();
            }, 60000 * refresh);

              

               






                            
                           
                                           





