(function() {

    var width, height, canvas, ctx, triangles, target;
    var colors = [ColorTriangle1,ColorTriangle2,ColorTriangle3,ColorTriangle4,ColorTriangle5];
	var dpi = window.devicePixelRatio;

    // Main
    initHeader();
	animate();
	
    function initHeader() {
        width = window.innerWidth * dpi;
        height = window.innerHeight * dpi;
        target = {x: 0, y: height};

        canvas = document.getElementById('canvas');
        canvas.width = width;
        canvas.height = height;
        ctx = canvas.getContext('2d');

        // create particles
        triangles = [];
        for(var x = 0; x < ParticuleNb; x++) {
			setTimeout(function() {
				var t = new Triangle();
				triangles.push(t);
			}, 50 * x);
        }
    }

    // Event handling
    /*function addListeners() {
        window.addEventListener('resize', resize);
    }

    function resize() {
        width = window.innerWidth;
        height = window.innerHeight;
        canvas.width = width;
        canvas.height = height;
    }*/

    function animate() {
		ctx.clearRect(0,0,width,height);
		for(var i in triangles) {
			triangles[i].draw();
		}
		setTimeout(function() {
			animate();
		}, 1000 / 70);
    }

    // Canvas manipulation
    function Triangle() {
        var _this = this;

        // constructor
        (function() {
            init();
        })();

        function init() {
			_this.coords = [{},{},{}];
            _this.pos = {};
			_this.step = 0;
			_this.rand = Math.random();
			_this.rand2 = Math.random();
			_this.rand3 = Math.random();
			_this.disp = 0;
            _this.pos.x = Math.random()*width;
            _this.pos.y = Math.random()*height;
            _this.coords[0].x = Math.random()*60*dpi;
            _this.coords[0].y = Math.random()*60*dpi;
            _this.coords[1].x = Math.random()*60*dpi;
            _this.coords[1].y = Math.random()*60*dpi;
            _this.coords[2].x = Math.random()*60*dpi;
            _this.coords[2].y = Math.random()*60*dpi;
            _this.scale = 0.1+Math.random()*0.3;
            _this.color = colors[Math.floor(Math.random()*colors.length)];
            _this.alpha = 0;
			var func = function() {
				_this.alpha += 0.03;
				if(_this.alpha > 1) {
					_this.alpha = 1;
					_this.disp = 1;
				} else {
					setTimeout(func, 60);
				}
			};
			func();
        }
		
        this.draw = function() {
			if(_this.disp == 1 && _this.step * _this.rand2 * _this.rand3 * 0.00005 > Math.random()) {
				_this.disp = 2;
			}
			if(_this.disp == 2) {
				if(_this.alpha >= 0.003)  {
					_this.alpha -= 0.003;
				} else {
					_this.alpha = 0;
					init();
					return;
				}
			}
			_this.step += 1;
			var val = _this.step * 0.005 * _this.rand, round = function(a) {return a > 0.5 ? 1 : 0; };
			_this.pos.x += Math.random() * ([-1,1][round(_this.rand2)]) * 0.4;
			_this.pos.y += Math.random() * ([-1,1][round(_this.rand3)]) * 0.4;
            ctx.beginPath();
            ctx.moveTo(
				_this.pos.x + Math.cos(val) * _this.coords[0].x, 
				_this.pos.y + Math.sin(val) * _this.coords[0].y
			);
            ctx.lineTo(
				_this.pos.x + Math.cos(val) * _this.coords[1].x, 
				_this.pos.y + Math.sin(val) * _this.coords[1].y
			);
            ctx.lineTo(
				_this.pos.x + Math.cos(val) * _this.coords[2].x, 
				_this.pos.y + Math.sin(val) * _this.coords[2].y
			);
            ctx.closePath();
            ctx.fillStyle = 'rgba('+_this.color+','+ _this.alpha+')';
            ctx.fill();
        };

        this.init = init;
    }
    
})();