var twentyfourh = true; // không thay đổi
var pad = true; // không thay đổi
