var ColorTriangle1 = "20,20,20";
var ColorTriangle2 = "30,30,30";
var ColorTriangle3 = "40,40,40"; 
var ColorTriangle4 = "50,50,50"; 
var ColorTriangle5 = "60,60,60"; //Format rgb = red, blue, green, max value is 255 and min 0 ; color chosen randomly
var ParticuleNb = "100";