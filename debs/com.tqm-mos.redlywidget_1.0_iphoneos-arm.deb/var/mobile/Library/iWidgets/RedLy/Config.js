var iconSet = "Mos"; 
var twentyfourhour = true; 
var pad = true; 
