var timeInterval = setInterval(function() {
	var date = new Date();
	
	var secRot = ((date.getSeconds()*6)+(date.getMilliseconds()/1000*6));
	var minRot = ((date.getMinutes()/60*360)+(secRot/360*6));
	
	var hours = function() {
		if (date.getHours() == 0 || date.getHours() == 12) {
			return 12;
		} else if (date.getHours() < 12) {
			return date.getHours();
		} else {
			return date.getHours() - 12;
		}
	};
	var hRot = ((hours()/12*360)+(minRot/360*6));
	$("img.hours").css({
		"-webkit-transform": "rotate("+hRot+"deg)"
	});
	$("img.minutes").css({
		"-webkit-transform": "rotate("+minRot+"deg)"
	});

	$("img.seconds").css({
		"-webkit-transform": "rotate("+secRot+"deg)"
	});
	
	var days = ["SUN","MON","TUE","WED","THU","FRI","SAT"];
	$('p.day').html(date.getDate());
}, 50);