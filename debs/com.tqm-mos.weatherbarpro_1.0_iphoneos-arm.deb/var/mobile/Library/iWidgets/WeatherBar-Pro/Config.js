var Lang = "vn"; // Chọn một trong hai ngôn ngữ "vn" hoặc "en"
var gpsswitch = true; // Kích hoạt GPS
var refreshrate = 2; // Khoảng thời gian cập nhật thời tiết. (Tính bằng phút)
var IconSet = "Icon"; // NO Edit"
var IconSet2 = "Icon2"; // NO Edit"
