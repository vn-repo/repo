# SnowBoard Localisation
![SnowBoard Icon](https://i.imgur.com/du1jZL7.png)

Let's localise SnowBoard!
Simply submit a pull request or contact SparkDev on Discord or [Twitter][ST].

# Contributions

## Chinese
### JJ
Twitter: [@JJGadgets][JJT]
Discord: JJGadgets#1337

## maaya1989
Twitter:
Discord:

## Acreson
Twitter: 
Discord:

## French
### relisiuol
Twitter: [relisiuol](https://twitter.com/relisiuol)
GitHub: [relisiuol](https://github.com/relisiuol)

## German
### Emy
Twitter:
Discord: Emy#0001

## Russian
### gkeep
GitHub: [gkeep](https://github.com/gkeep)
Discord: gkeep#2332

## Turkish
### MustyAslan99
Twitter:
Discord:

## Korean
### BawAppie
Twitter: [@BawAppie](https://tiwtter.com/BawAppie)

## Italian
### bart172
Twitter:
Discord

## French
### relisiuol
Twitter: 
Discord:

## Persian
### behradjafari1
Twitter: 
Discord:

## Arabic
### iA7myd
Twitter: 
Discord:

## Czech
### Toooorch
Twitter: 
Discord:

## Bangladesh
### atifchy
Twitter: 
Discord:

[ST]: https://twitter.com/SparkDev_ "Spark's Twitter"
[JJT]: https://twitter.com/JJGadgets "JJ's Twitter"
