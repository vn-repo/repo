var Lang = "vn"; // Chọn một trong hai ngôn ngữ "vn" hoặc "en"
var gpsswitch = true; // Kích hoạt GPS
var refreshrate = 2; // Khoảng thời gian cập nhật thời tiết. (Tính bằng phút)
var IconSet = "Icon"; // Chọn gói biểu tượng thời tiết của bạn ở đây. "Icon" , "Icon2" hoặc "Icon3"
