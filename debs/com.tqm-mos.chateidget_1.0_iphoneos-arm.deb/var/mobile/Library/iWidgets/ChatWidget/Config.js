var Clock = "12h"; // choose between "12h" or "24h"
var Lang = "en"; 
var MyTwitter = "@imo7and"; // follow me on Twitter
