var twentyfourhour = true;
var pad = true;
var IconSet = "Icon"; // Không thay đổi
var Lang = "en"; // Không thay đổi

