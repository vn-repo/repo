var iPhoneType = "auto"; // "iPhG", "iPhPlus" or "iPhX" or "iPhXMax" .Tuỳ chọn các máy ( iPhG = 6/7/8 ) , ( iPhPlus = Các máy Plus ) , ( iPhX và iPhXMax thì không cần nói 🤣, hoặc để ( auto ) , tự động căn chỉnh .
var QuangMinh = "😉•0868.388.373•❤️"; // Tuỳ chọn ký tự.
var QuangMinh1 = "Quang Minh"; // Tuỳ chọn ký tự.
var QuangMinh2 = "Menu"; // Tuỳ chọn ký tự.
var QuangMinh3 = "Chọn"; // Tuỳ chọn ký tự.
var twentyfourhour = true; // Bặt hoặc tắt. Định dạng 24h
var pad = true; // Bặt hoặc tắt. Định dạng giờ vd.( 00 ) hoặc ( 0 )
