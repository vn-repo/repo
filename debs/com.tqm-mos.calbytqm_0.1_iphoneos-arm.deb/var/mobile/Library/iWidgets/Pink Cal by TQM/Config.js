var twentyfourh = true; // không thay đổi
var pad = true; // không thay đổi
var textcolor = "ffffff"; // tuỳ chọn màu tuỳ ý
