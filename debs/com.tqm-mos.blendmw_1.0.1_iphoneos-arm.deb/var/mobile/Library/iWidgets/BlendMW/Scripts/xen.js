
//--------------------------- XENINFO ---------------------------
function mainUpdate(type){ 
	if(type === "weather"){
		checkWeather();
	}else if (type === "battery"){
		updateBattery();	  	
	}else if (type == "statusbar"){
		sigBars(document.getElementById("wl2"),parseInt(wifiBars), 3);
		sigCBars(signalBars);
	}
}

//------------------------- SIGNAL FUNCTIONS ---------------------------
function sigBars(indicator,_curr, _max){
	indicator.style.width = _curr * 40 / _max + 'px';
}

function sigCBars(_curr){
	//if(name === "carr"){
		if(_curr === "0"){
			document.getElementById("caS1").style.opacity = 0.5;
			document.getElementById("caS2").style.opacity = 0.5;
			document.getElementById("caS3").style.opacity = 0.5;
			document.getElementById("caS4").style.opacity = 0.5;
		}
		if(_curr === "1"){
			document.getElementById("caS1").style.opacity = 1;
			document.getElementById("caS2").style.opacity = 0.5;
			document.getElementById("caS3").style.opacity = 0.5;
			document.getElementById("caS4").style.opacity = 0.5;
		}
		if(_curr === "2"){
			document.getElementById("caS1").style.opacity = 1;
			document.getElementById("caS2").style.opacity = 1;
			document.getElementById("caS3").style.opacity = 0.5;
			document.getElementById("caS4").style.opacity = 0.5;
		}
		if(_curr === "3"){
			document.getElementById("caS1").style.opacity = 1;
			document.getElementById("caS2").style.opacity = 1;
			document.getElementById("caS3").style.opacity = 1;
			document.getElementById("caS4").style.opacity = 0.5;
		}
		if(_curr === "4"){
			document.getElementById("caS1").style.opacity = 1;
			document.getElementById("caS2").style.opacity = 1;
			document.getElementById("caS3").style.opacity = 1;
			document.getElementById("caS4").style.opacity = 1;
		}
	//}
}

//------------------------- WEATHER FUNCTIONS ---------------------------
function checkWeather(){
	//document.getElementById('_condition').innerHTML = weather.condition;
	document.getElementById('_weatherIcon').src = 'weather/' + weather.conditionCode + '.png';
	document.getElementById('_temp').innerHTML = weather.feelsLike + 'º';
	document.getElementById('_mm').innerHTML = weather.high + 'º<br>' + weather.low + 'º';
	
}


//------------------------- BATTERY FUNCTIONS ---------------------------
var startAnim = false;
//var batteryPercent;
//var batteryCharging = 1;
//updateBattery();
function updateBattery() {
	"use strict";
	//if(ba === 1){
		var batt = document.getElementById("battery");
		//batteryPercent = 20;
		batt.innerHTML = batteryPercent + '%';
		
		if(baCC === 0){
			if(batteryPercent > 80 && batteryPercent <= 100){
				document.getElementById("bl2").style.background = '#84BD35';
			}else if(batteryPercent > 50 && batteryPercent <= 80){
				document.getElementById("bl2").style.background = '#A1B963';
			}else if(batteryPercent > 20 && batteryPercent <= 50){
				document.getElementById("bl2").style.background = '#E8C04E';
			}else if(batteryPercent >= 0 && batteryPercent <= 20){
				document.getElementById("bl2").style.background = '#F68565';
			}
		}
		
		if(batteryCharging === 1){
			startAnim = true;
			chargeAnim();
		}else{
			startAnim = false;
			document.getElementById("bl2").style.width = batteryPercent * 80 / 100 + 'px';
		}
	//}
}

//------------------------ CHARGE ANIMATION ----------------------------------
function chargeAnim(){
	if(startAnim === true){
		TweenMax.to(document.getElementById("bl2"), 5, {alpha:0, width:'80px', onComplete:function(){
			document.getElementById("bl2").style.width = '0px';
			document.getElementById("bl2").style.opacity = 1;
			chargeAnim();
		}});
	}
}
