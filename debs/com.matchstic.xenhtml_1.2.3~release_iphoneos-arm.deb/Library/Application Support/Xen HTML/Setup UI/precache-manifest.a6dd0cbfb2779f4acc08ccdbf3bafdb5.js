self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "52e494d444eaaba37de0",
    "url": "css/app.7499817f.css"
  },
  {
    "revision": "ef09a475671582c95481c5719060ac67",
    "url": "index.html"
  },
  {
    "revision": "52e494d444eaaba37de0",
    "url": "js/app.ebc0342d.js"
  },
  {
    "revision": "a7979a49ee52bb6c18c3",
    "url": "js/chunk-vendors.b807a1c0.js"
  },
  {
    "revision": "ce75a34f2dfbfdffb6e5e1a10229bbc1",
    "url": "manifest.json"
  }
]);