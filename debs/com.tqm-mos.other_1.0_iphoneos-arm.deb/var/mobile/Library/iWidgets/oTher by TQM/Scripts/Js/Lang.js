if (Lang == "vn") {
    var days = ["Chủ nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy"];
    var months=["01","02","03","04","05","06","07","08","09","10","11","12"];
    var weatherdesc = ["Lốc tố", "Bão nhiệt đới", "Có bão", "Có giông", "Có giông", "Tuyết rơi", "Mưa đá", "Mưa đá", "Mưa phùn", "Mưa phùn", "Trời lạnh", "Có mưa", "Có mưa", "Đang mưa", "Có bão", "Tuyết rơi", "Tuyết rơi", "Tuyết rơi", "Mưa đá", "Mưa đá", "Mưa bay", "Sương mù", "Sương mù", "Sương mù", "Gió mạnh", "Có gió", "Trời lạnh", "Nhiều mây", "Nhiều mây", "Nhiều mây", "Nhiều mây", "Nhiều mây", "Trời quang", "Trời đẹp", "Trời trong", "Trời trong", "Mưa đá", "Trời nóng", "Sấm sét", "Sấm sét", "Sấm sét", "Có mưa", "Tuyết rơi", "Tuyết rơi", "Tuyết rơi", "Ít mây", "Có giông", "Có giông", "Có giông", "blank"]
}

if (Lang == "en") {
    var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    var months=["01","02","03","04","05","06","07","08","09","10","11","12"];
    var weatherdesc = ["Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank"];
} 