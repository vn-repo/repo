
window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);



function init(){
	updateClock();
	setInterval("updateClock();", 1000);
	checkSettings();
}

function checkSettings(){
	document.documentElement.style.setProperty('--primary', C1);
	document.documentElement.style.setProperty('--wiC', C2);
	document.documentElement.style.setProperty('--siC', C3);
	document.documentElement.style.setProperty('--tiC', C4);
	document.documentElement.style.setProperty('--weC', C5);
	
	document.documentElement.style.setProperty('--sc', sc);
	document.documentElement.style.setProperty('--bl', bl + 'px');
	document.documentElement.style.setProperty('--lineTh', lt + 'px');
	
	document.getElementById("innerCont").style.background = bg;
	
	/*if(ti === 0){
		document.getElementById("_time").style.display = 'none';
		document.getElementById("wifiCont").style.left = '35px';
		document.getElementById("signalCont").style.left = '35px';
	}*/
	
	if(wc === 0){
		document.getElementById("wifiCont").style.display = 'none';
		document.getElementById("signalCont").style.display = 'none';
	}
	
	if(ba === 0){
		document.getElementById('battCont').style.display = 'none';
		/*document.getElementById("weatCont").style.right = '40px';
		document.getElementById("_temp").style.fontSize = '14px';
		document.getElementById("_temp").style.top = '4px';
		document.getElementById("_temp").style.left = '20px';*/
	}
	
	if(baCC === 1){
		document.documentElement.style.setProperty('--batC', baC);
		document.documentElement.style.setProperty('--batTC', batC);
	}
	
	if(we === 0){
		document.getElementById("weatCont").style.display = 'none';
		//document.getElementById("battCont").style.right = '35px';
	}
	
}

//------------------------- TIME FUNCTIONS ---------------------------
function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	//var Time24 = 1;
	
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	
	document.getElementById("_time").innerHTML = currentHours + ":" + currentMinutes1;
	document.getElementById("_date").innerHTML = days[currentTime.getDay()] + ', ' + shortmonths[currentTime.getMonth()] + ' ' + currentDate;
	
}

