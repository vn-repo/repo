var Lang = "en"; // Chọn một trong hai ngôn ngữ "vn" hoặc "en"
var gpsswitch = true; // Kích hoạt GPS
var refreshrate = 500; // Khoảng thời gian cập nhật thời tiết. (Tính bằng phút)
var IconSet = "Icon"; // Không thay đổi
