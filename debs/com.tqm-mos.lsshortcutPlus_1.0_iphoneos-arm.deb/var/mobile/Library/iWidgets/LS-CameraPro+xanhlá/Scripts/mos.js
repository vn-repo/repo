/* */ var savedElements = {"overlay":"","placedElements":{"boxOne":{"left":"243px","border-color":"rgb(127,255,0)","border-width":"1px","position":"absolute","border-radius":"30px","width":"39px","box-shadow":"rgb(127,255,0) 0px 0px 12px","background":"linear-gradient(150deg,rgba(32,178,170,0.50),rgba(255,255,255,0) 50%,rgba(255,50,200, 0.50) 90%)","height":"39px","background-color":"rgba(130, 130, 130, 0.38)","z-index":"1","border-style":"solid","top":482,"-webkit-transform":"rotate(0deg)"}},"iconName":"simply"}


