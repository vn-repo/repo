var city = "San Francisco";
var woeid = 2487956;
var unit = "imperial";
var timeOffset = -7;

if (!localStorage.getItem("weatherData") || Math.floor((new Date(JSON.parse(localStorage.weatherData).validThru) -  (new Date))/(1000*60)) == 0) {
	$.getJSON("https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20geo.placefinder%20where%20woeid%20%3D%20%22"+woeid+"%22%20and%20gflags=%22%22&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys", function(cityData) {
		
		weather = {
			location: cityData.query.results.Result,
			unit: unit,
			timeOffset: timeOffset
		}
		
		$.ajax({
			url:"http://api.weather.com/v1/geocode/"+weather.location.latitude+"/"+weather.location.longitude+"/aggregate.json?apiKey=e45ff1b7c7bda231216c7ab7c33509b8&products=conditionsshort,fcstdaily10short,fcsthourly24short,nowlinks",
			cache: true,
			success: function(weatherData) {
				weather.data = weatherData;
				weather.validThru = new Date((new Date).setMinutes((new Date).getMinutes()+15));
				localStorage.setItem("weatherData",JSON.stringify(weather));
			}
		});
	});
}

$(document).ready(function() {
	/*if (!navigator.onLine) {
		var images = {
			"11": "rain-day",
			"12": "rain-day",
			"26": "mostly-cloudy-day",
			"27": "mostly-cloudy-night",
			"28": "mostly-cloudy-day",
			"29": "partly-cloudy-night",
			"30": "partly-cloudy-day",
			"31": "clear-night",
			"32": "mostly-sunny",
			"33": "clear-night",
			"34": "mostly-sunny"
		}
		
		for (var i=0; i<=0; i++) {
			for (var j=0; j<=11; j++) {
				var sin = Math.sin(Math.PI*((j+1)*30/180))*70;
				sin = ((sin<1&&sin>-1)) ? 0 : sin;
				var cos = -Math.cos(Math.PI*((j+1)*30/180))*70;
				cos = ((cos<1&&cos>-1)) ? 0 : cos;
				$('div.weather-container').append("<p class=\"hour\" id=\"hour"+(j+1)+"\">"+(j+1)+"</p>");
				$('p.hour#hour'+(j+1)).css({
					"transform": "translate3d("+sin+"px,"+cos+"px,0)"
				});
			}
			for (var k=0; k<=11; k++) {
				var sin = Math.sin(Math.PI*((k+1)*30/180))*130;
				sin = ((sin<1&&sin>-1)) ? 0 : sin;
				var cos = -Math.cos(Math.PI*((k+1)*30/180))*130;
				cos = ((cos<1&&cos>-1)) ? 0 : cos;
				$('div.weather-container').append("<div class=\"weather\" id=\"weather"+(k+1)+"\"></div>");
				$('div.weather-container').append("<div class=\"temp-hourly\" id=\"temp"+(k+1)+"\"></div>");
				$('div.weather-container').append("<div class=\"rain-hourly\" id=\"rain"+(k+1)+"\"></div>");
				$('div.weather#weather'+(k+1)).css({
					"transform": "translate3d("+sin+"px,"+cos+"px,0)"
				});
				$('div.temp-hourly#temp'+(k+1)).css({
					"transform": "translate3d("+sin+"px,"+cos+"px,0)"
				});
				$('div.rain-hourly#rain'+(k+1)).css({
					"transform": "translate3d("+sin+"px,"+cos+"px,0)"
				});
			}
		}
	
		(function(){
			$('div.weather-container').addClass("loaded");
			$('p#temp-label').html(((app.weather.unit=="imperial"))?"&deg;F":"&deg;C");
			
			var date = new Date();
			var compareDate = new Date(app.weather.data.fcsthourly24short.forecasts[0].fcst_valid_local.replace(/-/,"/").replace(/-/,"/").replace(/T/," "));
			
			var data = app.weather.data;
			var hours = get24hours(date.getUTCHours()+app.weather.timeOffset);
			
			$('div#weather'+hours).html("<img src=\"apps/com.apple.weather/assets/"+images[data.conditionsshort.observation.wx_icon.toString()]+"@2x.png\" style=\"margin:auto\">");
			$('div.temp-hourly#temp'+hours).html(data.conditionsshort.observation[app.weather.unit].temp);
			$('div.rain-hourly#rain'+hours).html(data.fcsthourly24short.forecasts[0].pop);

			for (var i=1; i<=11; i++) {
				$('div#weather'+get24hours(hours+(i))).html("<img src=\"apps/com.apple.weather/assets/"+images[data.fcsthourly24short.forecasts[i-1].icon_cd.toString()]+"@2x.png\" style=\"margin:auto\">");
				$('div#temp'+get24hours(hours+(i))).html(data.fcsthourly24short.forecasts[i-1][app.weather.unit].temp);
				$('div.rain-hourly#rain'+get24hours(hours+(i))).html(data.fcsthourly24short.forecasts[i-1].pop);
			}
			$('p#temp').html(data.conditionsshort.observation[app.weather.unit].temp+"&deg;");

			$('div.weather-container').append('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 308 308" enable-background="new 0 0 308 308" xml:space="preserve"><g><g opacity="0.25"><path id="time" fill="none" stroke="#FFFFFF" stroke-width="7.4" stroke-miterlimit="10" d="'+describeArc(154,154,94.3,(hours*30)+(date.getMinutes()/60*30),(hours+11)*30)+'"/></g></g></svg>');
	
			$('div.hour-indicator').css({
				"transform": "translate3d("+(Math.sin(Math.PI * (((hours*30)+(date.getMinutes()/60*30))/180))*94.3)+"px,"+(-Math.cos(Math.PI * (((hours*30)+(date.getMinutes()/60*30))/180))*94.3)+"px,0)"
			});

			$('line').show();
			
			$('p.hour').show();
			
			$('div.weather-container.fcst div.weather').show();
			$('div.weather-container.temp div.temp-hourly').show();
			$('div.weather-container.rain div.rain-hourly').show();

			if (date.getMinutes() >= 10) {
				$('p.hour#hour'+hours).hide();
				$('line#line-hour'+hours).hide();
				$('div.weather-container div.weather#weather'+hours).hide();
				$('div.weather-container div.temp-hourly#temp'+hours).hide();
				$('div.weather-container div.rain-hourly#rain'+hours).hide();
			}
		
			var weatherHourIndicator = setInterval(function() {
				hours = get24hours((new Date).getUTCHours()+app.weather.timeOffset);
				$('div.hour-indicator').css({
					"transform": "translate3d("+(Math.sin(Math.PI * (((hours*30)+((new Date).getMinutes()/60*30))/180))*94.3)+"px,"+(-Math.cos(Math.PI * (((hours*30)+((new Date).getMinutes()/60*30))/180))*94.3)+"px,0)"
				});
				$('path#time').attr("d", describeArc(154,154,94.3,(hours*30)+((new Date).getMinutes()/60*30),(hours+11)*30));
				
				$('line').show();

				$('p.hour').show();

				if ((new Date).getMinutes() >= 10) {
					$('p.hour#hour'+hours).hide();
					$('line#line-hour'+hours).hide();
					$('div.weather-container div.weather#weather'+hours).hide();
					$('div.weather-container div.temp-hourly#temp'+hours).hide();
					$('div.weather-container div.rain-hourly#rain'+hours).hide();
				}
			}, 5000);
		})();
		
		$('div.weather-container').on("touchstart mousedown", function() {
			$(this).css({
				"transform":"scale(0.96710526)",
				"opacity":0.6
			});
		});
		$('div.weather-container').on("click",function() {
			var el = $(this);
			
			el.removeAttr("style");
			if (el.hasClass("fcst")) {
				el.removeClass("fcst");
				el.addClass("temp");
			} else if (el.hasClass("temp")) {
				el.removeClass("temp");
				el.addClass("rain");
			} else if (el.hasClass("rain")) {
				el.removeClass("rain");
				el.addClass("fcst");
			}
		});
		$('div.navbar a.link.watch-home').html($('div.navbar a.link.watch-home').html().replace(/{{city}}/g, city));
		$('a.link.watch-home').on("click", function() {
			app.watch.core.home(true);
		});
	} else {
		$('div.navbar a.link.watch-home').html($('div.navbar a.link.watch-home').html().replace(/{{city}}/g, "Offline"));
		$('a.link.watch-home').on("click", function() {
			app.watch.core.home(true);
		});
	}*/
});

var get24hours = function(input) {
	if (input > 12) {
		return input-12;
	} else if (input <= 0) {
		return input + 12;
	} else {
		return input;
	}
};


function polarToCartesian(centerX, centerY, radius, angleInDegrees) {
  var angleInRadians = (angleInDegrees-90) * Math.PI / 180.0;

  return {
    x: centerX + (radius * Math.cos(angleInRadians)),
    y: centerY + (radius * Math.sin(angleInRadians))
  };
}

function describeArc(x, y, radius, startAngle, endAngle){

    var start = polarToCartesian(x, y, radius, endAngle);
    var end = polarToCartesian(x, y, radius, startAngle);

    var arcSweep = endAngle - startAngle <= 180 ? "0" : "1";

    var d = [
        "M", start.x, start.y, 
        "A", radius, radius, 0, arcSweep, 0, end.x, end.y
    ].join(" ");

    return d;       
}
$(document).ready(function() {
	if (!localStorage.getItem("weatherData") || Math.floor((new Date(JSON.parse(localStorage.weatherData).validThru) -  (new Date))/(1000*60)) == 0 || JSON.parse(localStorage.weatherData).locationWOEID != woeid || JSON.parse(localStorage.weatherData).timeOffset != timeOffset || JSON.parse(localStorage.weatherData).unit != unit) {
		$.getJSON("https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20geo.placefinder%20where%20woeid%20%3D%20%22"+woeid+"%22%20and%20gflags=%22%22&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys", function(cityData) {
			
			var weather = {
				location: cityData.query.results.Result,
				locationWOEID: woeid,
				unit: unit,
				timeOffset: timeOffset,
				unit: unit
			}
			
			$.ajax({
				url:"http://api.weather.com/v1/geocode/"+weather.location.latitude+"/"+weather.location.longitude+"/aggregate.json?apiKey=e45ff1b7c7bda231216c7ab7c33509b8&products=conditionsshort,fcstdaily10short,fcsthourly24short,nowlinks",
				cache: true,
				success: function(weatherData) {
					weather.data = weatherData;
					weather.validThru = new Date((new Date).setMinutes((new Date).getMinutes()+15));
					localStorage.setItem("weatherData",JSON.stringify(weather));
					weather = undefined;
					initWeatherView(JSON.parse(localStorage.getItem("weatherData")));
				}
			});
		});
	} else {
		initWeatherView(JSON.parse(localStorage.getItem("weatherData")));
	}
});

function initWeatherView(weather) {
	var images = {
		"11": "rain-day",
		"12": "rain-day",
		"26": "mostly-cloudy-day",
		"27": "mostly-cloudy-night",
		"28": "mostly-cloudy-day",
		"29": "partly-cloudy-night",
		"30": "partly-cloudy-day",
		"31": "clear-night",
		"32": "mostly-sunny",
		"33": "clear-night",
		"34": "mostly-sunny"
	}
	
	for (var i=0; i<=0; i++) {
		for (var j=0; j<=11; j++) {
			var sin = Math.sin(Math.PI*((j+1)*30/180))*70;
			sin = ((sin<1&&sin>-1)) ? 0 : sin;
			var cos = -Math.cos(Math.PI*((j+1)*30/180))*70;
			cos = ((cos<1&&cos>-1)) ? 0 : cos;
			$('div.weather-container').append("<p class=\"hour\" id=\"hour"+(j+1)+"\">"+(j+1)+"</p>");
			$('p.hour#hour'+(j+1)).css({
				"transform": "translate3d("+sin+"px,"+cos+"px,0)"
			});
		}
		for (var k=0; k<=11; k++) {
			var sin = Math.sin(Math.PI*((k+1)*30/180))*130;
			sin = ((sin<1&&sin>-1)) ? 0 : sin;
			var cos = -Math.cos(Math.PI*((k+1)*30/180))*130;
			cos = ((cos<1&&cos>-1)) ? 0 : cos;
			$('div.weather-container').append("<div class=\"weather\" id=\"weather"+(k+1)+"\"></div>");
			$('div.weather-container').append("<div class=\"temp-hourly\" id=\"temp"+(k+1)+"\"></div>");
			$('div.weather-container').append("<div class=\"rain-hourly\" id=\"rain"+(k+1)+"\"></div>");
			$('div.weather#weather'+(k+1)).css({
				"transform": "translate3d("+sin+"px,"+cos+"px,0)"
			});
			$('div.temp-hourly#temp'+(k+1)).css({
				"transform": "translate3d("+sin+"px,"+cos+"px,0)"
			});
			$('div.rain-hourly#rain'+(k+1)).css({
				"transform": "translate3d("+sin+"px,"+cos+"px,0)"
			});
		}
	}
	(function(){
		$('div.weather-container').addClass("loaded");
		$('p#temp-label').html(((weather.unit=="imperial"))?"&deg;F":"&deg;C");
		
		var date = new Date();
		var compareDate = new Date(weather.data.fcsthourly24short.forecasts[0].fcst_valid_local.replace(/-/,"/").replace(/-/,"/").replace(/T/," "));
		
		var data = weather.data;
		var hours = get24hours(date.getUTCHours()+weather.timeOffset);
		
		$('div#weather'+hours).html("<img src=\"assets/"+images[data.conditionsshort.observation.wx_icon.toString()]+"@2x.png\" style=\"margin:auto\">");
		$('div.temp-hourly#temp'+hours).html(data.conditionsshort.observation[weather.unit].temp);
		$('div.rain-hourly#rain'+hours).html(data.fcsthourly24short.forecasts[0].pop);

		for (var i=1; i<=11; i++) {
			$('div#weather'+get24hours(hours+(i))).html("<img src=\"assets/"+images[data.fcsthourly24short.forecasts[i-1].icon_cd.toString()]+"@2x.png\" style=\"margin:auto\">");
			$('div#temp'+get24hours(hours+(i))).html(data.fcsthourly24short.forecasts[i-1][weather.unit].temp);
			$('div.rain-hourly#rain'+get24hours(hours+(i))).html(data.fcsthourly24short.forecasts[i-1].pop);
		}
		$('p#temp').html(data.conditionsshort.observation[weather.unit].temp+"&deg;");

		$('div.weather-container').append('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 308 308" enable-background="new 0 0 308 308" xml:space="preserve"><g><g opacity="0.25"><path id="time" fill="none" stroke="#FFFFFF" stroke-width="7.4" stroke-miterlimit="10" d="'+describeArc(154,154,94.3,(hours*30)+(date.getMinutes()/60*30),(hours+11)*30)+'"/></g></g></svg>');

		$('div.hour-indicator').css({
			"transform": "translate3d("+(Math.sin(Math.PI * (((hours*30)+(date.getMinutes()/60*30))/180))*94.3)+"px,"+(-Math.cos(Math.PI * (((hours*30)+(date.getMinutes()/60*30))/180))*94.3)+"px,0)"
		});

		$('line').show();
		
		$('p.hour').show();
		
		$('div.weather-container.fcst div.weather').show();
		$('div.weather-container.temp div.temp-hourly').show();
		$('div.weather-container.rain div.rain-hourly').show();
		
		if (date.getMinutes() >= 10) {
			$('p.hour#hour'+hours).hide();
			$('line#line-hour'+hours).hide();
			$('div.weather-container div.weather#weather'+hours).hide();
			$('div.weather-container div.temp-hourly#temp'+hours).hide();
			$('div.weather-container div.rain-hourly#rain'+hours).hide();
		}
	
		var weatherHourIndicator = setInterval(function() {
			hours = get24hours((new Date).getUTCHours()+weather.timeOffset);
			$('div.hour-indicator').css({
				"transform": "translate3d("+(Math.sin(Math.PI * (((hours*30)+((new Date).getMinutes()/60*30))/180))*94.3)+"px,"+(-Math.cos(Math.PI * (((hours*30)+((new Date).getMinutes()/60*30))/180))*94.3)+"px,0)"
			});
			$('path#time').attr("d", describeArc(154,154,94.3,(hours*30)+((new Date).getMinutes()/60*30),(hours+11)*30));
			
			$('line').show();

			$('p.hour').show();

			if ((new Date).getMinutes() >= 10) {
				$('p.hour#hour'+hours).hide();
				$('line#line-hour'+hours).hide();
				$('div.weather-container div.weather#weather'+hours).hide();
				$('div.weather-container div.temp-hourly#temp'+hours).hide();
				$('div.weather-container div.rain-hourly#rain'+hours).hide();
			}
		}, 5000);
	})();

	$('div.weather-container').on("touchstart mousedown", function() {
		$(this).css({
			"transform":"scale(0.96710526)",
			"opacity":0.6
		});
	});
	$('div.weather-container').on("click",function() {
		var el = $(this);
		
		el.removeAttr("style");
		if (el.hasClass("fcst")) {
			el.removeClass("fcst");
			el.addClass("temp");
		} else if (el.hasClass("temp")) {
			el.removeClass("temp");
			el.addClass("rain");
		} else if (el.hasClass("rain")) {
			el.removeClass("rain");
			el.addClass("fcst");
		}
	});
}

