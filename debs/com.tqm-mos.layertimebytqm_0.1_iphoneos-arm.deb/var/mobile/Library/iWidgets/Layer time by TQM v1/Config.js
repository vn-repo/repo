var twentyfourhour = true; 
var pad = true; 
var IconSet = "White"; // tuỳ chọn "Black" hoặc "White"
var textcolor = "black"; // tuỳ chọn màu tuỳ ý
