var OscillationRange = 40;
var OscillationFrequency = 0.01;
var StayWolf = 3; //in sec
var FillPolygons = true;