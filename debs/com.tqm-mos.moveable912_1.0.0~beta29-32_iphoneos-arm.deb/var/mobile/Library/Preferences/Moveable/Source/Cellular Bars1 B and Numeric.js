(height, signalStrengthRaw, isTintBlack, extraOption, color)
{
	var lowerLimit = -130, upperLimit = -80;
	var range = Math.abs(lowerLimit - upperLimit);

	var percentage = 0;
	if (signalStrengthRaw <= lowerLimit) {
		percentage = 0;
	} else if (signalStrengthRaw >= upperLimit) {
		percentage = 100;
	} else {
		percentage = Math.round(100 * (signalStrengthRaw - lowerLimit) / range);
	}

	var
		canvas = document.createElement("canvas"),
		context = canvas.getContext("2d"),
		spacer = Math.round(height / 20.0),
		barWidth = Math.round(height / 7),
		barHeight = height / 2.0,
		mainColor = "rgb(" + color.join() + ")",
		canvasHeight = height,
		canvasWidth = Math.round(barWidth * 5 + 4 * spacer);

	canvas.width = canvasWidth * 3;
	canvas.height = canvasHeight;

	var y = barHeight + (canvasHeight - barHeight) / 2;

	context.fillStyle = mainColor;
	for (var i = 0; i < 5; i++) {
		var heightLocal = 0;
		if (percentage > 20.0 * (i + 1))
			heightLocal = 1;
		else
			heightLocal = (percentage - 20.0 * i) / 20.0;

		if (heightLocal < 0)
			heightLocal = 0;
		else if (heightLocal > 1)
			heightLocal = 1;

		var maxBarHeight = ((i + 1) * barHeight / 5.0) - 2;

		heightLocal = -Math.round(heightLocal * maxBarHeight);
		heightLocal -= 2;

		context.fillRect(i * barWidth + i * spacer, y, barWidth, heightLocal);
	}

	var fontHeight = 0.45 * height;

	context.font = fontHeight + "pt -apple-system";
	context.textAlign = "left";
	context.textBaseline = "middle";
	context.fillText(-signalStrengthRaw, canvasWidth + 4 * spacer, height / 2);

	var
		croppedCanvas = document.createElement("canvas"),
		croppedContext = croppedCanvas.getContext("2d");

	croppedCanvas.width = canvasWidth + 4 * spacer + context.measureText(-signalStrengthRaw).width;
	croppedCanvas.height = canvasHeight;

	croppedContext.drawImage(canvas, 0, 0);

	return croppedCanvas.toDataURL("image/png");
}
