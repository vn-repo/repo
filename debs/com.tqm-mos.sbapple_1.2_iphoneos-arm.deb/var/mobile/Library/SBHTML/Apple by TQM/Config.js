var left = "red"; // Tuỳ chọn màu Trái.
var right = "red"; // Tuỳ chọn màu Phải.
var Apple = "gold"; // Tuỳ chọn màu Quả Táo.
var QuangMinh = ""; // Tuỳ chọn ký tự. "".
var scle = 1; // Tuỳ chỉnh kích cỡ
