var twentyfourhour = true; // Trần Quang Minh
var pad = true; // Trần Quang Minh




