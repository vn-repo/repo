function calendarDate ( )
{if (Lang == "vn"){
	var this_weekday_name_array= ["Trần•Quang•Minh","Trần•Quang•Minh•","Trần•Quang•Minh","Trần•Quang•Minh","Trần•Quang•Minh","Trần•Quang•Minh","Trần•Quang•Minh"];}
  var this_date_timestamp = new Date()	  
  var this_weekday = this_date_timestamp.getDay()
document.getElementById("weekday").firstChild.nodeValue = this_weekday_name_array[this_weekday] //concat long date string
}