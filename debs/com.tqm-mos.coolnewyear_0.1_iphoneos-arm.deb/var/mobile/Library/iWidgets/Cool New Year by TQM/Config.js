var twentyfourhour = true;
var pad = true;
var IconSet = "Icon"; // chọn "Icon" hoặc "Icon2"
var Lang = "en"; // Không thay đổi
