<!-------------------------------------------------- Code by Schnedi ------------------------------------------------>



function calendarDate ( )

{

       var this_date_name_array = new Array("00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31")



	if (Lang == "en"){

	var this_weekday_name_array=["Chủ Nhật","Thứ Hai","Thứ Ba","Thứ Tư","Thứ Năm","Thứ Sáu","Thứ Bảy"];

	var this_month_name_array=["January","tháng hai","tháng ba","tháng tư","tháng năm","June","July","August","September","10","11","12"];

	}

	if (Lang == "fr"){

	var this_weekday_name_array=["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];

       var this_month_name_array=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];

	}

	if (Lang == "de"){

	var this_weekday_name_array = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];

       var this_month_name_array=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];

	}

	if (Lang == "ca"){

	var this_weekday_name_array = ["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"];

	var this_month_name_array=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

	}

	if (Lang == "it"){

	var this_weekday_name_array = ["Domenica","Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato"];

	var this_month_name_array=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];

	}



  var this_date_timestamp = new Date()	  

  var this_weekday = this_date_timestamp.getDay()    

  var this_date = this_date_timestamp.getDate()    

  var this_month = this_date_timestamp.getMonth()  

  var this_year = this_date_timestamp.getYear()  



if (this_year < 1000)

    this_year+= 1900;

if (this_year==101)

    this_year=2001;	   



document.getElementById("weekday").firstChild.nodeValue = this_weekday_name_array[this_weekday] //concat long date string

document.getElementById("date").firstChild.nodeValue = this_date_name_array[this_date] + "." //concat long date string

document.getElementById("month").firstChild.nodeValue = this_month_name_array[this_month] + "." //concat long date string

document.getElementById("year").firstChild.nodeValue = this_year //concat long date string

}