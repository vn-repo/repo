var Clock = "24h"; // "12h" or "24h"
var Lang = "en"; // "ca" castellano, "it" italiano, "fr" français, "de" deutsch, "en" english
