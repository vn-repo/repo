var borderColour = "darkGrey";
var temperatureColour = "lightGrey";
var backgroundColour = "black";
