var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'en',
    $$ = function (el) {
        return document.getElementById(el);
    },
    translate = {
        en: {
            weekday: ["S u n d a y","M o n d a y","T u e s d a y","W e d n e s d a y","T h u r s d a y","F r i d a y","S a t u r d a y"],
            sday: ["S u n d a y","M o n d a y","T u e s d a y","W e d n e s d a y","T h u r s d a y","F r i d a y","S a t u r d a y"],
            month: ["J a n u a r i", "F e b r u a r i", "M a a r t", "A p r i l", "M e i", "J u n i", "J u l i", "A u g u s t u s", "S e p t e m b e r", "O k t o b e r", "N o v e m b e r", "D e c e m b e r"],
            smonth: ["J a n u a r i", "F e b r u a r i", "M a a r t", "A p r i l", "M e i", "J u n i", "J u l i", "A u g u s t u s", "S e p t e m b e r", "O k t o b e r", "N o v e m b e r", "D e c e m b e r"]

        }
    };
if (!translate[current]) {
    current = 'en';
}
