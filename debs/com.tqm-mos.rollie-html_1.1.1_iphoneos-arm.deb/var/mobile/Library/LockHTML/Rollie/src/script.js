var hoursEl = document.getElementById('hours'),
    minutesEl = document.getElementById('minutes'),
    secondsEl = document.getElementById('seconds'),
    dateEl = document.getElementById('date'),
    locationEl = document.getElementById('location'),
    tempEl = document.getElementById('temperature'),
    percentEl = document.getElementById('percentage'),
    mainColor = document.getElementsByClassName('mainColor');

function runTheTicker()
{
    var date = new Date();
    var hoursPos = date.getHours() * 360 / 12 + ((date.getMinutes() * 360 / 60) / 12),
        minutesPos = (date.getMinutes() * 360 / 60) + (date.getSeconds() * 360 / 60) / 60,
        secondsPos = date.getSeconds() * 360 / 60;

    hoursEl.style.transform = `rotate(${hoursPos}deg)`;
    minutesEl.style.transform = `rotate(${minutesPos}deg)`;
    secondsEl.style.transform = `rotate(${secondsPos}deg)`;

    for (var i = 0; i < mainColor.length; i++) {
        mainColor[i].style.color = mainColor;
        mainColor[i].style.fill = mainColor;
    }

    setTimeout(runTheTicker, 1000);

    if (typeof appearance !== "undefined")
    {
        if (appearance) {
            document.body.classList = "dark";
        }
        else {
            document.body.classList = "light";
        }
    }
}

function mainUpdate(type)
{
    switch (type) {
        case "battery":
            percentEl.innerHTML = batteryPercent;
            break;

        case "weather":
            locationEl.innerHTML = `${weather.address.city}, ${weather.address.country}`
            tempEl.innerHTML = `${weather.temperature}°`;
    
        default:
            break;
    }

    clock({
        twentyfour: false,
        padzero: false,
        refresh: 5000,
        success: function (clock) {
            dateEl.innerHTML = `<span class="mainColor">${clock.date()}</span> ${translate[current].smonth[clock.month()]}`;
        }
    });
}

runTheTicker();