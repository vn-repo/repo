var twentyfourh = true; // không thay đổi
var pad = true; // không thay đổi
var IconSet = "Icon2"; // Tuỳ chọn "Icon" hoặc "Icon2"
