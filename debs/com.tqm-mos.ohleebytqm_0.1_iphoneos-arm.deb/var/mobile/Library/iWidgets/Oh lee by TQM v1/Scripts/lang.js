var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'en',
    $$ = function (el) {
        return document.getElementById(el);
    },
    translate = {
        en: {
            weekday: ["S u n d a y","M o n d a y","T u e s d a y","W e d n e s d a y","T h u r s d a y","F r i d a y","S a t u r d a y"],
            sday: ["S u n d a y","M o n d a y","T u e s d a y","W e d n e s d a y","T h u r s d a y","F r i d a y","S a t u r d a y"],
            month: ["January","February","March","April","May","June","July","August","September","October","November","December"],
            smonth: ["January","February","March","April","May","June","July","August","September","October","November","December"]
        }
    };
if (!translate[current]) {
    current = 'en';
}
