var day = Array("Chủ nhật "," Thứ hai "," Thứ ba "," Thứ tư "," Thứ năm "," Thứ sáu "," Thứ bảy ");
var month = Array("1","2","3","4","5","6","7","8","9" ,"10","11","12");
today = new Date();
var year = today.getYear();

if ((navigator.appName == "Microsoft Internet Explorer") && (year < 2000))
year="19" + year;
if (navigator.appName == "Netscape")
year=1900 + year;

document.write('<p>'+day[today.getDay()]+', '+today.getDate()+' - '+month[today.getMonth()]+' - '+year+'</p>');