var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'en',
    $$ = function (el) {
        return document.getElementById(el);
    },
    translate = {
        en: {
            weekday: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            sday: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            month: ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"],
            smonth: ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"]
        },
       vi: {
            weekday: ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ năm", "Thứ 6", "Thứ 7"],
            sday: ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ năm", "Thứ 6", "Thứ 7"],
            month: ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"],
            smonth: ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"]
        }
    };
if (!translate[current]) {
    current = 'en';
}
